package cn.yumetsuki.lab4.model

class MFD: Directory("root", null){

    val userDirectoryList = arrayListOf<UFD>()



}