package cn.yumetsuki.lab4.model

data class Result<T>(val data: T)