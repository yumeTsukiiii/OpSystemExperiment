package cn.yumetsuki.lab4

interface FileInterface {

    val path: String

    val name: String

}