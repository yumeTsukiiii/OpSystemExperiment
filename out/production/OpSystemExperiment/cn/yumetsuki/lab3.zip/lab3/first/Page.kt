package cn.yumetsuki.lab3.first

class Page(
    val pageIndex: Int,
    val memoryIndex: Int,
    var location: String,
    var flag: Boolean = false
)